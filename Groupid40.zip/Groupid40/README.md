# A Comparative Analysis of Graph Neural Networks for Recommender Systems

The aim of this study is to investigate the different models and architectures used to implement recommender systems and compare them against each other. We experiment on LightGCN, UltraGCN, and NGCF.

This is meant solely for the submission of academic project for the course CZ4032 - Data Analytics and Mining 23S1.
